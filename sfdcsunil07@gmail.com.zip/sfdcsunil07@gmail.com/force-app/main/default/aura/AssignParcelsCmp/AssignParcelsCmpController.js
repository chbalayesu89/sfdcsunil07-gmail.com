({
    doInit : function(component, event, helper) {
        //get parcel list
      console.log('parcelIds:'+component.get("v.parcelIds"));
      component.set("v.isModalOpen",true);
    },
    handleCancelClick:function(component,event,helper){
        component.set("v.isModalOpen", false);
        window.history.back();
    },
    handleSaveClick:function(component,event,helper){   
        try{    
        let selectedDataObj=component.get("v.selectedDataObj");
        let parcelaccess=component.find("parcelaccess").get("v.value");       
        let parcelIds=component.get("v.parcelIds");   
        let pIdlist=[];
        if(parcelIds.includes(',')){
            pIdlist=parcelIds.split(',');
        }else{
            pIdlist.push(parcelIds);
        }
        console.log('parcelIds:'+JSON.stringify(pIdlist));
        let params={selectedDataObj:JSON.stringify(selectedDataObj),
                    parcelAccess:parcelaccess,                    
                    parcelIds:pIdlist
                   };
        console.log('params:'+JSON.stringify(params));
        var action = component.get("c.doShareParcel");
        action.setParams(params);
        action.setCallback(this, function (response) {
            try{
            var state = response.getState();
            if (state === "SUCCESS") {
                alert('Parcels Assigned Successfully');
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "The record has been shared successfully."
                });
                toastEvent.fire();
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();           
            }
            component.set("v.isModalOpen", false);
            window.history.back();
        }catch(err){
            console.log('error:'+err.stack);
        }
        });
        $A.enqueueAction(action);
    }catch(err){
        console.log('Exception:'+err.stack);
    }
    },   
})