({
    doInit : function(component, event, helper) {
        //get parcel list
        var action=component.get("c.getParcelList");
        let params={
            recordId:component.get("v.recordId")
           };
            console.log('params:'+JSON.stringify(params));
            action.setParams(params);
            action.setCallback(this, function (response) {
                var state = response.getState();
                if (state === "SUCCESS") {
                    component.set("v.parcellist",response.getReturnValue());
                }
                else{
                    var errorMsg = action.getError()[0].message;
                    console.log(errorMsg);
                    var toastEvent = $A.get("e.force:showToast");
                    toastEvent.setParams({
                        title: 'Error',
                        type: 'error',
                        message: errorMsg
                    });
                    toastEvent.fire();     
                }
            });
            $A.enqueueAction(action);
    },
    handleCancelClick:function(component,event,helper){
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
    },
    handleSaveClick:function(component,event,helper){
        var action = component.get("c.doShareParcel");
        let selectedDataObj=component.get("v.selectedDataObj");
        let parcelaccess=component.find("parcelaccess").get("v.value");
        let parcellist=component.get("v.parcellist");
        let parcelIds=[];
        for(let x=0;x<parcellist.length;x++){
            if(parcellist[x].selected){
                parcelIds.push(parcellist[x].id);
            }
        }
        console.log('parcelIds:'+JSON.stringify(parcelIds));
        let params={selectedDataObj:JSON.stringify(selectedDataObj),
                    parcelAccess:parcelaccess,                    
                    parcelIds:parcelIds
                   };
        console.log('params:'+JSON.stringify(params));
        action.setParams(params);
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "The record has been shared successfully."
                });
                toastEvent.fire();
            }else{
                var errorMsg = action.getError()[0].message;
                console.log(errorMsg);
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    title: 'Error',
                    type: 'error',
                    message: errorMsg
                });
                toastEvent.fire();           
            }
            var dismissActionPanel = $A.get("e.force:closeQuickAction");
            dismissActionPanel.fire();
        });
        $A.enqueueAction(action);
        
    },
    selectAll:function(component,event,helper){
        console.log('selectAll clicked');
        let allselected=event.target.checked;
        console.log('value:'+allselected);
       
        let parcellist=component.get("v.parcellist");
        if(allselected){
            for(let x=0;x<parcellist.length;x++){
                parcellist[x].selected=true;
            }
            component.set("v.parcellist",parcellist);
        }else{
            for(let x=0;x<parcellist.length;x++){
                parcellist[x].selected=false;
            }
            component.set("v.parcellist",parcellist);
        }
    }
})