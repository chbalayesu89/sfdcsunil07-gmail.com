({
    doInit : function(component, event, helper) {
        var urlEvent = $A.get("e.force:navigateToURL");
    urlEvent.setParams({
      "url": "/lightning/o/NEER_Project__c/list?filterName=00B5g00000VrT3eEAF"
    });
    urlEvent.fire();
    }
})