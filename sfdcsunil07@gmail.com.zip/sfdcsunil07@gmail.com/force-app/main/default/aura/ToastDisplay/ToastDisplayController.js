({
    doInit : function(component,event,helper) {
        helper.showToastMessage(component);
    }    
})