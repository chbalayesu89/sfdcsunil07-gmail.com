({
    showToastMessage : function(component) {
        var vfpath = "https://" + component.get("v.vfPath");
        window.addEventListener("message", function(event) {
            if ( (event.data.type) && (event.data.type=='EventFromVF') )
                debugger;
                if (event.origin !== vfpath) {
                    return;
                }
            var toastEvent = $A.get('e.force:showToast');
            toastEvent.setParams({
                type: event.data.type,
                message: event.data.message,
                mode: event.data.mode
            });
            toastEvent.fire();
            console.log(event.data);
        }, false);
    }
})