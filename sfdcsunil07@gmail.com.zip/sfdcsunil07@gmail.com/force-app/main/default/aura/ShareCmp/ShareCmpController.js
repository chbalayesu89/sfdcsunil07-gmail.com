({
    doInit : function(component, event, helper) {
        
    },
    handleCancelClick:function(component,event,helper){
        var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
    },
    handleSaveClick:function(component,event,helper){
        var action = component.get("c.doShareParcel");
        let selectedDataObj=component.get("v.selectedDataObj");
        let parcelaccess=component.find("parcelaccess").get("v.value");
        let params={selectedDataObj:JSON.stringify(selectedDataObj),
                    parcelAccess:parcelaccess,
                    recordId:component.get("v.recordId")
                   };
        console.log('params:'+JSON.stringify(params));
        action.setParams(params);
        action.setCallback(this, function (response) {
            var state = response.getState();
            if (state === "SUCCESS") {
                var toastEvent = $A.get("e.force:showToast");
                toastEvent.setParams({
                    "title": "Success!",
                    "message": "The record has been shared successfully."
                });
                toastEvent.fire();
            }
            var dismissActionPanel = $A.get("e.force:closeQuickAction");
            dismissActionPanel.fire();
        });
        $A.enqueueAction(action);
        
    }
})