/**
 * @File Name          : projectSearch.js
 * @Description        : 
 * @Author             : Sunil
 * @Group              : 
 * @Last Modified By   : Sunil
 * @Last Modified On   : 26 Sept
 * Ver                 : 1.0
**/

import { LightningElement,wire } from 'lwc';
import getProject from "@salesforce/apex/projectSearchController.getProjectList";
const actions = [
    { label: 'Show Details', name: 'show_details' },
    { label: 'Delete', name: 'delete' },
];

const columns = [
    { label: 'Name', fieldName: 'Name' },
    { label: 'Project Name', fieldName: 'Project_Name__c' },
    { label: 'Project Number', fieldName: 'NEER_Project_Number__c'},
    { label: 'Project Staus', fieldName: 'Project_Status__c'},
    { label: 'Project Type', fieldName: 'Project_Type__c' },
    { label: 'Project Developer', fieldName: 'Project_Developer__c' },
    { label: 'County', fieldName: 'County__c' },
    { label: 'State', fieldName: 'NEER_State__c' },
    { label: 'Country', fieldName: 'NEER_Country_Name__c' },
    { label: 'Priority', fieldName: 'Priority__c' },
    { label: 'Update date', fieldName: 'Update_date__c' },
    { label: 'GIS', fieldName: 'GIS__c' },
    {
        type: 'action',
        typeAttributes: { rowActions: actions },
    },
];
export default class ProjectSearch extends LightningElement {
    value = 'Name';
    action = 'Land Agent Assignment';
    data = [];
    columns = columns;
    record;
    get options() {
        return [
            { label: 'Project Name', value: 'Name' },
            { label: 'Project Number', value: 'NEER_Project_Number__c' },
        ];
    }
    get actionOptions() {
        return [
            { label: 'Land Agent Assignment', value: 'Land Agent Assignment' },
            { label: 'Supervisor Agent Assignment', value: 'Supervisor Agent Assignment' },
            { label: 'Developer Agent Assignment', value: 'Developer Agent Assignment' },
                 ];
    }
    @wire(getProject, {})
  wiredDetail(result) {
    if (result.data) {
      console.log(result.data);
      this.data = result.data;
    }
    if (result.error) {
      console.log("wire==>" + result.error.body.message);
    }
  }
    handleChange(event) {
        this.value = event.detail.value;
    }
    handleActionChange(event) {
        this.action = event.detail.value;
    }
}