import { LightningElement } from 'lwc';
export default class NeerFooter extends LightningElement {

}