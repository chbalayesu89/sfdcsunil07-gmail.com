import { LightningElement } from 'lwc';
import dataTableResource from '@salesforce/resourceUrl/JqueryDatatableRes';
import fixedHeader from '@salesforce/resourceUrl/DatatableFixedHeaderJs';
import {loadScript,loadStyle} from 'lightning/platformResourceLoader';
import {ShowToastEvent} from 'lightning/platformShowToastEvent';

import getProjects from '@salesforce/apex/NextEraHomeController.getProjects';

const tableColumns = [
    { label: 'Project Id', fieldName: 'Id'},
    { label: 'Project Number', fieldName: 'NEER_Project_Number__c'},
    { label: 'Project Name', fieldName: 'Project_Name__c'}
];

export default class LwcJqueryDatatable extends LightningElement {

    tableData = [];

    async connectedCallback() {
        await this.getProjects();
        Promise.all([
            loadScript(this, dataTableResource + '/js/jquery-3.5.1.js'),
            loadScript(this, dataTableResource + '/js/jquery.dataTables.min.js'),
            //loadScript(this, dataTableResource + '/js/header.min.js'),
            //loadScript(this, dataTableResource + '/js/dataTables.fixedHeader.min.js'),
            loadScript(this, fixedHeader),
            loadStyle(this, dataTableResource + '/css/jquery.dataTables.min.css'),
            loadStyle(this, dataTableResource + '/css/fixedHeader.dataTables.min.css'),
        ]).then(() => {
            console.log('script loaded sucessfully');
            const table = this.template.querySelector('.project-table');
            const col_defs = [];

            tableColumns.forEach( column =>  {
                console.log(column.label+'>>>>>>>>>'+column.fieldName);
                col_defs.push({"title": column.label,"data":column.fieldName,"defaultContent": ""});
            })
            var test = "tehis is toe test";
            console.log(test);

            $(document).ready(function() {
                let jqTable = $(table).DataTable({   
                    orderCellsTop: true,
                    fixedHeader: true,
                    initComplete: function () {
                        var api = this.api();
                        // For each column
                        api
                        .columns()
                        .eq(0)
                        .each(function (colIdx) {
                            // Set the header cell to contain the input element
                            var cell = $('.filters th').eq(
                                $(api.column(colIdx).header()).index()
                            );
                            var title = $(cell).text();
                            $(cell).html('<input type="text" placeholder="' + title + '" />');

                            // On every keypress in this input
                            $(
                                'input',
                                $('.filters th').eq($(api.column(colIdx).header()).index())
                            )
                                .off('keyup change')
                                .on('keyup change', function (e) {
                                    e.stopPropagation();

                                    // Get the search value
                                    $(this).attr('title', $(this).val());
                                    var regexr = '({search})'; //$(this).parents('th').find('select').val();

                                    var cursorPosition = this.selectionStart;
                                    // Search the column for that value
                                    api
                                        .column(colIdx)
                                        .search(
                                            this.value != ''
                                                ? regexr.replace('{search}', '(((' + this.value + ')))')
                                                : '',
                                            this.value != '',
                                            this.value == ''
                                        )
                                        .draw();

                                    $(this)
                                        .focus()[0]
                                        .setSelectionRange(cursorPosition, cursorPosition);
                                });
                        });
                    },
                });
            });

            /*$(document).ready(function() {
                let jqTable = $(table).DataTable({
                    dom: "Bfrtip",
                    data: [{}],
                    "columns":this.col_defs,
                });
            });*/

        }).catch(error => {
            console.log('here the error to show'+error);
            this.error = error;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error!!',
                    message: JSON.stringify(error),
                    variant: 'error',
                }),
            );
        });
    }

    async getProjects() {
        await getProjects()
            .then(data => {
                if (data) {
                    this.tableData = data;
                }
            })
            .catch(error => {
                this.error = error;
                this.accounts = undefined;
                this.error = 'Unknown error';
                if (Array.isArray(error.body)) {
                    this.error = error.body.map(e => e.message).join(', ');
                } else if (typeof error.body.message === 'string') {
                    this.error = error.body.message;
                }
                this.dispatchEvent(
                    new ShowToastEvent({
                        title: 'Error!!',
                        message: error,
                        variant: 'error',
                    }),
                );
            });
    }

}