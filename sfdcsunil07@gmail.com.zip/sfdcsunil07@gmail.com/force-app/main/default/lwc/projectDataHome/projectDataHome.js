import { LightningElement,track,api } from 'lwc';
import Headerzip_Images from '@salesforce/resourceUrl/project_data_icons_headerzip';

export default class ProjectDataHome extends LightningElement {
    @track searchKey='';
    @track columnName='';
    @track ownerUnassigned=true;
    @track project_data_icon = Headerzip_Images+'/Header/LOGO/icon_title_bar_project_search.svg#ICON_TITLE_BAR_PROJECT_SEARCH';
   /* 
    @api set searchKey(value) {
        this.searchKey = value;
    }
    get searchKey() {
        return this.searchKey;
    }

    @api set columnName(value) {
        this.columnName = value;
    }
    get columnName() {
        return this.columnName;
    }
*/

//This method receives event from child and retrieves salesforce data based on input
    doSearch(event){
        console.log('doSearch running');
        console.log('searchKey:'+event.detail.searchKey);
        console.log('columnName:'+event.detail.columnName);
        this.searchKey=event.detail.searchKey;
        this.columnName=event.detail.columnName;
        this.ownerUnassigned=event.detail.ownerUnassigned;
        this.template
      		.querySelectorAll('c-project-data-home-tabs')[0]
      		.dosearch(this.searchKey,this.columnName,this.ownerUnassigned);
    }

}