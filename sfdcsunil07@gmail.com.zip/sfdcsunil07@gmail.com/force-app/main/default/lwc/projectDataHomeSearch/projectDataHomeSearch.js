import { LightningElement,track } from 'lwc';

export default class ProjectDataHomeSearch extends LightningElement {
    @track searchByValue = 'Unassigned';
    @track ownerUnassigned=true; 
    @track searchKey='';
    
    actionToPerformValue = 'Land Agent Assignment';

    get actionToPerformOptions() {
        return [
            { label: 'Land Agent Assignment', value: 'Land Agent Assignment' },
            { label: 'Supervisor Agent Assignment', value: 'Supervisor Agent Assignment' },
            { label: 'Developer Agent Assignment', value: 'Developer Agent Assignment' },
        ];
    }

    //this method sets actionToPerform option
    handleActionToPerformChange(event) {
        this.actionToPerformValue = event.detail.value;
    }

    

    get searchByOptions() {    
        return [
            { label: 'Unassigned', value: 'Unassigned' },
            { label: 'Project ID', value: 'Project_ID__c' },
            { label: 'Project Number', value: 'NEER_Project_Number__c' },
            { label: 'Project Name', value: 'Name' },
            { label: 'Project Status', value: 'Project_Status__c' },
            { label: 'Project Type', value: 'Type__c' },
            { label: 'Project Developer', value: 'Project_Developer__c' },           
            { label: 'Priority', value: 'Priority__c' },
            { label: 'Update Date', value: 'Update_date__c' },
            { label: 'Country', value: 'NEER_Country_Name__c' },
            { label: 'State', value: 'NEER_State__c' },
            { label: 'County', value: 'NEER_County_Name__c' }
        ];
    }

    //this method handles searchbyvalue change
    handleSearchByChange(event) {
        this.searchByValue = event.detail.value;
    }

   //this method handles searchkey change
    handleSearchKeyChange(event) {
        console.log('searchkey changed..');
        this.searchKey = event.detail.value;
        const selectedEvent = new CustomEvent("search", {
            detail: {columnName:this.searchByValue,searchKey:this.searchKey}
          });      
          // Dispatches the event.
          this.dispatchEvent(selectedEvent);
    }

}