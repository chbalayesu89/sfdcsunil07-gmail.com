import { LightningElement } from 'lwc';

import My_Resource from '@salesforce/resourceUrl/neeLogo';
import My_icons from '@salesforce/resourceUrl/neeIconsStyle';
//import svg_logout from '@salesforce/resourceUrl/icon_settings';


export default class StaticResourceLWCExample extends LightningElement {
    neeLogo = My_Resource + '/neeLogo.jpg';
    settingIcon = My_icons + '/icon_settings.jpg'
    menuIcon = My_icons + '/icon_menu.jpg'
    logoutIcon = My_icons + '/icon_log_out.jpg'
    profileIcon = My_icons + '/icon_user.jpg'
    notifIcon = My_icons + '/icon_notification.jpg'
   // logOutIcon = `${svg_logout}#ICON_LOG_OUT`;
}