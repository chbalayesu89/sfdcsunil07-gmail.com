import { LightningElement, wire } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';

export default class ProjectListviewLwc extends NavigationMixin(LightningElement) {
    connectedCallback() {
       // this.navigateToListView();
       // window.open('/lightning/o/NEER_Project__c/list?filterName=00B5g00000VrT3eEAF','_target');
    }
    navigateToListView() {
        // Navigate to the Contact object's Recent list view.
        this[NavigationMixin.Navigate]({
            type: 'standard__objectPage',
            attributes: {
                objectApiName: 'NEER_Project__c',
                actionName: 'list'
            },
            state: {
                // 'filterName' is a property on the page 'state'
                // and identifies the target list view.
                // It may also be an 18 character list view id.
                filterName: '00B5g00000VrT3eEAF' // or by 18 char '00BT0000002TONQMA4'
            }
        });
    }
    
}