import { LightningElement } from 'lwc';
export default class LwcFooter extends LightningElement {

}