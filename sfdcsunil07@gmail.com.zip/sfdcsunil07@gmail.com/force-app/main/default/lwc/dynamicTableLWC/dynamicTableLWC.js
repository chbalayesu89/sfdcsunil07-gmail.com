import { LightningElement } from 'lwc';
export default class DynamicTableLWC extends LightningElement {

}