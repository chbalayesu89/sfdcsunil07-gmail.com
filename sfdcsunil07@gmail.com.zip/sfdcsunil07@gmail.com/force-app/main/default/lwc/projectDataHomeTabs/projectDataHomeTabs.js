import { LightningElement, wire, track, api } from 'lwc';
import findRecords from "@salesforce/apex/ProjectDataHomeController.search";
import findRecordsWithMultiSearch from "@salesforce/apex/ProjectDataHomeController.multisearch";
import Headerzip_Images from '@salesforce/resourceUrl/project_data_icons_headerzip';

export default class ProjectDataHomeTabs extends LightningElement {

    /*value = 'inProgress';

    get options() {
        return [
            { label: 'New', value: 'new' },
            { label: 'In Progress', value: 'inProgress' },
            { label: 'Finished', value: 'finished' },
        ];
    }*/

    @track project_data_tablelayout_icon = Headerzip_Images + '/Header/icon_action_table_layout.svg#ICON_LAYOUT';
    @track project_data_icon = Headerzip_Images + '/Header/LOGO/icon_title_bar_project_search.svg#ICON_TITLE_BAR_PROJECT_SEARCH';

    handleChange(event) {
        this.value = event.detail.value;
    }

    @track searchKey = '';
    @track columnName = '';
    @track ownerUnassigned = true;
    @track data = [];
    @track original_data = [];
    @track columnDataArray=[];
    connectedCallback() {
        // console.log('tableLayoutOptions:'+JSON.stringify(this.tableLayoutOptions));
        this.columnDataArray=[];
        this.selectedTableColumnMap = new Map();
        for (let x = 0; x < this.tableLayoutOptions.length; x++) {
            // console.log('this.tableLayoutOptions[x].label:'+this.tableLayoutOptions[x].label);
            this.selectedTableColumnMap.set(this.tableLayoutOptions[x].label, this.tableLayoutOptions[x].value);
           // this.columnlabels.push(this.tableLayoutOptions[x].label);
        }
        this.columnDataArray=Array.from(this.selectedTableColumnMap, ([label, value]) => ({ label, value }));
        let mapkeys = Array.from( this.selectedTableColumnMap.keys() );
        console.log('mapkeys:'+mapkeys);
        console.log('selectedTableColumnMap:'+JSON.stringify(this.selectedTableColumnMap));
            if(mapkeys.includes('Project ID')){
                this.showProjectId=true;
            }else{
                this.showProjectId=false;
            }
            if(mapkeys.includes('Project Number')){
                this.showProjectNumber=true;
            }else{
                this.showProjectNumber=false;
            }
            if(mapkeys.includes('Project Name')){
                this.showName=true;
            }else{
                this.showName=false;
            }
            if(mapkeys.includes('Project Status')){
                this.showProjectStatus=true;
            }else{
                this.showProjectStatus=false;
            }
            if(mapkeys.includes('Project Type')){
                this.showType=true;
            }else{
                this.showType=false;
            }
            if(mapkeys.includes('Project Developer')){
                this.showProjectDeveloper=true;
            }else{
                this.showProjectDeveloper=false;
            }
            if(mapkeys.includes('Country')){
                this.showCountryName=true;
            }else{
                this.showCountryName=false;
            }
            if(mapkeys.includes('State') || mapkeys.includes('Province')){
                this.showState=true;
            }else{
                this.showState=false;
            }
            if(mapkeys.includes('County') || mapkeys.includes('City')){
                this.showCountyName=true;
            }else{
                this.showCountyName=false;
            }
            if(mapkeys.includes('Priority')){
                this.showPriority=true;
            }else{
                this.showPriority=false;
            }
            if(mapkeys.includes('Update Date')){
                this.showUpdateDate=true;
            }else{
                this.showUpdateDate=false;
            }     
        // console.log('selectedTableColumnMap:'+JSON.stringify(this.selectedTableColumnMap));
        this.retrieveProjects();
    }

    @track totalSize = 0;
    @track startIndex = 1;
    @track endIndex = 0;
    @track pagesize = 4;
    @track selected_item_count = 0;

    // this method shows the backpage on pagination
    backPage() {
        console.log('backpage running..');
        if (this.startIndex != 1) {
            this.data = [];
            let counter = 0;
            for (let x = this.startIndex - this.pagesize; x < this.startIndex; x++) {
                if (x > -1) {
                    this.data[counter++] = this.original_data[x];
                } else {
                    this.startIndex++;
                }
            }
            console.log('data:' + JSON.stringify(this.data));
            this.startIndex = this.startIndex - counter;
            this.endIndex = this.startIndex + this.pagesize - 1;
        }
    }

    //this method shows the next page of the pagination
    nextPage() {
        console.log('next page running');
        try {
            if (this.endIndex < this.totalSize) {
                this.data = [];
                let counter = 0;
                for (let x = this.endIndex; x < (this.endIndex + this.pagesize); x++) {
                    if (x < this.totalSize) {
                        this.data[counter++] = this.original_data[x];
                    }
                }
                this.startIndex = this.startIndex + this.pagesize;
                this.endIndex = this.endIndex + counter;
                console.log('data set >' + JSON.stringify(this.data));
            }
        } catch (err) {
            console.log('error:' + err.stack);
        }
    }

    //this method shows the last page of pagination
    lastPage() {
        let reminder = this.totalSize % this.pagesize;
        this.endIndex = this.totalSize - reminder;
        this.startIndex = this.endIndex - reminder + 1;
        this.data = [];
        let counter = 0;
        for (var i = this.endIndex; i < this.endIndex + this.pagesize; i++) {
            if (this.totalSize > i) {
                this.data[counter++] = this.original_data[i];
            }
        }
        this.startIndex = this.startIndex + counter;
        this.endIndex = this.endIndex + counter;
    }


    //this method retrieves the list of project records from salesforce
    retrieveProjects() {
        findRecords({ p_searchKey: this.searchKey, p_columnName: this.columnName, p_ownerUnassigned: this.ownerUnassigned })
            .then(result => {
                // console.log('result:' + JSON.stringify(result));
                this.original_data = result;
                this.data = [];
                this.totalSize = this.original_data.length;
                if (this.original_data.length > 0) {
                    let counter = 0;
                    for (let x = 0; x < this.pagesize; x++) {
                        if (x < this.totalSize) {
                            this.data[x] = this.original_data[x];
                            counter++;
                        }
                    }
                    this.endIndex = counter;
                } else {
                    this.data = [];
                }
                this.error = undefined;
            })
            .catch(error => {
                this.error = error;
                this.data = undefined;
                console.log('error setting default', error);
            });
    }

    @track multicolumnlist = {};

    @track isCanadaState = false;

    //this method retrieves salesforce data based on input key
    handleKeyChangeForUnassigned(event) {
        console.log('handleKeyChangeForUnassigned');
        this.columnName = event.currentTarget.dataset.id;
        console.log('columnName:'+this.columnName);
        //check if id includes extra information
       /* if (this.columnName.includes('-')) {
            this.columnName = this.columnName.split('-')[0];
        }*/
        this.searchKey = event.target.value;
        this.multicolumnlist[this.columnName] = this.searchKey;
        //change state label if country is canada
        if (this.searchKey.toUpperCase() == 'CANADA') {
            this.isCanadaState = true;
            //override state, county with province and city
         //   { label: 'State', value: 'NEER_State__c' },
         //   { label: 'County', value: 'NEER_County_Code__c' },
            //delete us entries
            this.selectedTableColumnMap.delete('State');
            this.selectedTableColumnMap.delete('County');
            //add canada entries
            this.selectedTableColumnMap.set('Province','NEER_State__c');
            this.selectedTableColumnMap.set('City','NEER_County_Name__c');
        } else {
            this.isCanadaState = false;
            //delete canada entries
            this.selectedTableColumnMap.delete('Province');
            this.selectedTableColumnMap.delete('City');
            //add us entries
            this.selectedTableColumnMap.set('State','NEER_State__c');
            this.selectedTableColumnMap.set('County','NEER_County_Name__c');
        }
        this.ownerUnassigned = true;
        this.columnDataArray=Array.from(this.selectedTableColumnMap, ([label, value]) => ({ label, value }));
        console.log('multicolumnlist:' + JSON.stringify(this.multicolumnlist));
        this.retrieveProjectsWithMultiSearch();
    }

    /*
    handleKeyChangeForAll(event){        
        this.columnName=event.target.id;
        this.searchKey=event.target.value;
        this.owncolerUnassigned=false;
        this.retrieveProjects();
    }*/

    tableLayoutValue = 'Name';

    get tableLayoutOptions() {
        return [
            { label: 'Project ID', value: 'Project_ID__c' },
            { label: 'Project Number', value: 'NEER_Project_Number__c' },
            { label: 'Project Name', value: 'Name' },
            { label: 'Project Status', value: 'Project_Status__c' },
            { label: 'Project Type', value: 'Type__c' },
            { label: 'Project Developer', value: 'Project_Developer__c' },                    
            { label: 'Priority', value: 'Priority__c' },
            { label: 'Update Date', value: 'Update_date__c' },
            { label: 'Country', value: 'NEER_Country_Name__c' },   
             { label: 'State', value: 'NEER_State__c' },
            { label: 'County', value: 'NEER_County_Name__c' },
        ];
    }

    @track selectedTableColumnMap = new Map();
   // @track selectedTableDataMap = [];

   //this method shows/hides table columns based on selection
    handleTableLayoutChange(event) {
        try {
            this.tableLayoutValue = event.detail;
            console.log('tableLayoutValue:' + this.tableLayoutValue);
            this.selectedTableColumnMap = new Map();
           // this.selectedTableDataMap = [];
            let tablelayoutvaluestr = this.tableLayoutValue;
            console.log('tablelayoutvaluestr:' + tablelayoutvaluestr);
            if(tablelayoutvaluestr==''){
                tablelayoutvaluestr=['Project_ID__c','NEER_Project_Number__c','Name','Project_Status__c','Type__c','Project_Developer__c','Priority__c','Update_Date__c','NEER_Country_Name__c','NEER_State__c','NEER_County_Name__c'];
            }
            this.columnlabels=[];
            for (let item of tablelayoutvaluestr) {
                console.log('item:' + item);
                if (item == 'Project_ID__c') {
                    this.selectedTableColumnMap.set('Project ID',item);
                   // this.columnlabels.push('Project ID');
                }
                if (item == 'NEER_Project_Number__c') {
                    this.selectedTableColumnMap.set('Project Number',item);
                   // this.columnlabels.push('Project Number');
                }
                if (item == 'Name') {
                    this.selectedTableColumnMap.set('Project Name', item);
                   // this.columnlabels.push('Project Name');
                }
                if (item == 'Project_Status__c') {
                    this.selectedTableColumnMap.set('Project Status',item);
                   // this.columnlabels.push('Project Status');
                }
                if (item == 'Type__c') {
                    this.selectedTableColumnMap.set('Project Type',item );
                   // this.columnlabels.push('Project Type');
                }
                if (item == 'Project_Developer__c') {
                    this.selectedTableColumnMap.set('Project Developer',item );
                   // this.columnlabels.push('Project Developer');
                }
                if (item == 'NEER_Country_Name__c') {
                    this.selectedTableColumnMap.set('Country',item );
                   // this.columnlabels.push('Country');
                }
                if (item == 'NEER_State__c') {
                    if(this.isCanadaState){
                        this.selectedTableColumnMap.set('Province',item );
                    //    this.columnlabels.push('Province');
                    }else{
                        this.selectedTableColumnMap.set('State',item );
                       // this.columnlabels.push('State');
                    }
                }
                if (item == 'NEER_County_Name__c') {
                    if(this.isCanadaState){
                        this.selectedTableColumnMap.set('City',  item);
                      //  this.columnlabels.push('City');
                    }else{
                        this.selectedTableColumnMap.set('County',item);
                      //  this.columnlabels.push('County');
                    }                   
                }
                if (item == 'Priority__c') {
                    this.selectedTableColumnMap.set( 'Priority',item );
                   // this.columnlabels.push('Priority');
                }
                if (item == 'Update_Date__c') {
                    this.selectedTableColumnMap.set( 'Update Date', item );
                   // this.columnlabels.push('Update Date');
                }
            }
            //console.log('selectedTableColumnMap:' + JSON.stringify(this.selectedTableColumnMap));
            this.columnDataArray=Array.from(this.selectedTableColumnMap, ([label, value]) => ({ label, value }));
            let mapkeys = Array.from( this.selectedTableColumnMap.keys() );
            if(mapkeys.includes('Project ID')){
                this.showProjectId=true;
            }else{
                this.showProjectId=false;
            }
            if(mapkeys.includes('Project Number')){
                this.showProjectNumber=true;
            }else{
                this.showProjectNumber=false;
            }
            if(mapkeys.includes('Project Name')){
                this.showName=true;
            }else{
                this.showName=false;
            }
            if(mapkeys.includes('Project Status')){
                this.showProjectStatus=true;
            }else{
                this.showProjectStatus=false;
            }
            if(mapkeys.includes('Project Type')){
                this.showType=true;
            }else{
                this.showType=false;
            }
            if(mapkeys.includes('Project Developer')){
                this.showProjectDeveloper=true;
            }else{
                this.showProjectDeveloper=false;
            }
            if(mapkeys.includes('Country')){
                this.showCountryName=true;
            }else{
                this.showCountryName=false;
            }
            if(mapkeys.includes('State') || mapkeys.includes('Province')){
                this.showState=true;
            }else{
                this.showState=false;
            }
            if(mapkeys.includes('County') || mapkeys.includes('City')){
                this.showCountyName=true;
            }else{
                this.showCountyName=false;
            }
            if(mapkeys.includes('Priority')){
                this.showPriority=true;
            }else{
                this.showPriority=false;
            }
            if(mapkeys.includes('Update Date')){
                this.showUpdateDate=true;
            }else{
                this.showUpdateDate=false;
            }            
        } catch (err) {
            console.log(err.stack);
        }
    }

    @track showProjectId=false;
    @track showProjectNumber=false;
    @track showName=false;
    @track showProjectStatus=false;
    @track showType=false;
    @track showProjectDeveloper=false;
    @track showCountryName=false;
    @track showState=false;
    @track showCountyName=false;
    @track showPriority=false;
    @track showUpdateDate=false;

//this method provides data based on top search box input
    @api dosearch(p_searchKey, p_columnName, p_ownerUnassigned) {
        console.log('tabs dosearch runnning...');
        this.searchKey = p_searchKey;
        this.columnName = p_columnName;
        this.owncolerUnassigned = p_ownerUnassigned;
        this.retrieveProjects();
    }


    @track selectAllEnabled = false;
    @track selectedRecordIds = [];

    //this method enables/disables all checkboxes
    selectAllClicked(event) {
        console.log('selectAllClicked running');
        let selectbox_value = event.target.checked;
        console.log('selectbox_value:' + selectbox_value);
        if (selectbox_value) {
            this.selectAllEnabled = true;
            for (let x = 0; x < this.data.length; x++) {
                if (!this.selectedRecordIds.includes(this.data[x].Id)) {
                    this.selectedRecordIds.push(this.data[x].Id);
                }
            }
        }
        else {
            this.selectAllEnabled = false;
            this.selectedRecordIds = [];
        }
    }

    //this method adds or removes selected/unselected checkboxes from the selectedlist of checkboxes
    selectClicked(event) {
        let checkboxId = event.currentTarget.dataset.id;
        console.log('checkboxId:' + checkboxId);
        let checkboxvalue = event.target.checked;
        console.log('checkboxvalue:' + checkboxvalue);
        if (checkboxvalue) {
            if (!this.selectedRecordIds.includes(checkboxId)) {
                //add element
                this.selectedRecordIds.push(checkboxId);
            }
        } else {
            if (this.selectedRecordIds.includes(checkboxId)) {
                //remove element
                const index = this.selectedRecordIds.indexOf(checkboxId);
                if (index > -1) {
                    this.selectedRecordIds.splice(index, 1);
                }
            }
        }
    }


    //this method retrieves salesforce data based on mulisearchboxes
    retrieveProjectsWithMultiSearch() {
        findRecordsWithMultiSearch({ p_multicolumnlist: JSON.stringify(this.multicolumnlist) })
            .then(result => {
                // console.log('result:' + JSON.stringify(result));
                this.original_data = result;
                this.data = [];
                this.totalSize = this.original_data.length;
                if (this.original_data.length > 0) {
                    for (let x = 0; x < this.pagesize; x++) {
                        if (x < this.totalSize) {
                            this.data[x] = this.original_data[x];
                        }
                    }
                    this.endIndex = this.pagesize;
                } else {
                    this.data = [];
                }
                this.error = undefined;
            })
            .catch(error => {
                this.error = error;
                this.data = undefined;
                console.log('error setting default', error);
            });
    }

//this method changes the tab
    changeTab(event) {
        //clear tabs
        this.template.querySelector('.slds-show').classList.add('slds-hide');
        this.template.querySelector('.slds-show').classList.remove('slds-show');
        this.template.querySelector('.slds-active').classList.remove('slds-active');

        //get clicked tab id
        var x = event.currentTarget.dataset.id;
        console.log('x:' + x);

        //get clicked tab element
        let xele = this.template.querySelector('li[data-id="' + x + '"]');
        xele.classList.add('slds-active');

        //display content
        let p = 'div[data-id="' + x + '_content"]';
        console.log('p:' + p);
        let target = this.template.querySelector(p);
        console.log('target:' + target);
        target.classList.remove('slds-hide');
        target.classList.add('slds-show');
    }
}