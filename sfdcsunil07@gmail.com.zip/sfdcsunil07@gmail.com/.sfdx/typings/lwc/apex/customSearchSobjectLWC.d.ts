declare module "@salesforce/apex/customSearchSobjectLWC.getContactList" {
  export default function getContactList(param: {searchKey: any}): Promise<any>;
}
