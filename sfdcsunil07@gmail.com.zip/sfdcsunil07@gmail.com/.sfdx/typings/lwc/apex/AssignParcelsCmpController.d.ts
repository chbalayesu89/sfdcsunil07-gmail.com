declare module "@salesforce/apex/AssignParcelsCmpController.doShareParcel" {
  export default function doShareParcel(param: {selectedDataObj: any, parcelAccess: any, parcelIds: any}): Promise<any>;
}
