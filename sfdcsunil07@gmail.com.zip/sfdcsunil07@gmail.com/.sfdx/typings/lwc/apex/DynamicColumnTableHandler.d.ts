declare module "@salesforce/apex/DynamicColumnTableHandler.getAllColumnsDetail" {
  export default function getAllColumnsDetail(param: {objectApiName: any}): Promise<any>;
}
declare module "@salesforce/apex/DynamicColumnTableHandler.showAddData" {
  export default function showAddData(param: {selectedField: any, objectName: any}): Promise<any>;
}
