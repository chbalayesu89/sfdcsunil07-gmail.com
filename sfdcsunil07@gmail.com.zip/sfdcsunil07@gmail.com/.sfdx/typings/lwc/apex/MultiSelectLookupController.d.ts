declare module "@salesforce/apex/MultiSelectLookupController.fetchRecords" {
  export default function fetchRecords(param: {objectName: any, filterField: any, searchString: any, values: any}): Promise<any>;
}
