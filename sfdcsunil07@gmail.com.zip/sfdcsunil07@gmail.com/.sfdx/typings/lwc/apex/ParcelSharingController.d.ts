declare module "@salesforce/apex/ParcelSharingController.doShareParcel" {
  export default function doShareParcel(param: {selectedDataObj: any, parcelAccess: any, recordId: any}): Promise<any>;
}
