declare module "@salesforce/apex/projectSearchController.getProjectList" {
  export default function getProjectList(param: {pageSize: any, pageNumber: any}): Promise<any>;
}
