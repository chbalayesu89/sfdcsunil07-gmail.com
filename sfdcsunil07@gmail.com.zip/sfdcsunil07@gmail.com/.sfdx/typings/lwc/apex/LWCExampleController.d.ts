declare module "@salesforce/apex/LWCExampleController.getContacts" {
  export default function getContacts(): Promise<any>;
}
declare module "@salesforce/apex/LWCExampleController.deleteContacts" {
  export default function deleteContacts(param: {lstConIds: any}): Promise<any>;
}
