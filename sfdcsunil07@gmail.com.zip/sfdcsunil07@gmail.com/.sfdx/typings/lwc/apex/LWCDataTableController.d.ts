declare module "@salesforce/apex/LWCDataTableController.initRecords" {
  export default function initRecords(param: {ObjectName: any, fieldNamesStr: any, recordId: any, Orderby: any, OrderDir: any, inlineEdit: any, enableColAction: any}): Promise<any>;
}
declare module "@salesforce/apex/LWCDataTableController.getsObjectRecords" {
  export default function getsObjectRecords(param: {ObjectName: any, fieldNameSet: any, LimitSize: any, recId: any, Orderby: any, OrderDir: any}): Promise<any>;
}
declare module "@salesforce/apex/LWCDataTableController.deleteSObject" {
  export default function deleteSObject(param: {sob: any}): Promise<any>;
}
declare module "@salesforce/apex/LWCDataTableController.updateRecords" {
  export default function updateRecords(param: {sobList: any, updateObjStr: any, objectName: any}): Promise<any>;
}
