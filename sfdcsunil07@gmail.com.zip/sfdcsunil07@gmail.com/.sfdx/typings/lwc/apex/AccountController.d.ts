declare module "@salesforce/apex/AccountController.getAccountList" {
  export default function getAccountList(param: {pageSize: any, pageNumber: any}): Promise<any>;
}
