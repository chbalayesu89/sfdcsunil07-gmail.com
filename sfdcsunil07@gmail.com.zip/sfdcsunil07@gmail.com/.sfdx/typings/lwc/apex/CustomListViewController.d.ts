declare module "@salesforce/apex/CustomListViewController.fetchRecs" {
  export default function fetchRecs(param: {listValues: any}): Promise<any>;
}
