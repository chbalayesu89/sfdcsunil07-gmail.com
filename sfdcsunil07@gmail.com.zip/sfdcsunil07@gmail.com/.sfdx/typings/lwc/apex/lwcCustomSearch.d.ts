declare module "@salesforce/apex/lwcCustomSearch.retriveAccs" {
  export default function retriveAccs(param: {strAccName: any}): Promise<any>;
}
