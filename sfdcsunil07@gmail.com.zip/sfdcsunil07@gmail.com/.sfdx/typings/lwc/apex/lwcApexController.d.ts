declare module "@salesforce/apex/lwcApexController.searchAccountNameMethod" {
  export default function searchAccountNameMethod(param: {accStrName: any, accStrPhone: any, accStrWebsite: any, accStrIndustry: any, accStrDescription: any}): Promise<any>;
}
