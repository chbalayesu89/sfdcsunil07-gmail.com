declare module "@salesforce/apex/AccountControllerInlineEdit.fetchAccounts" {
  export default function fetchAccounts(): Promise<any>;
}
declare module "@salesforce/apex/AccountControllerInlineEdit.updateAccounts" {
  export default function updateAccounts(param: {data: any}): Promise<any>;
}
