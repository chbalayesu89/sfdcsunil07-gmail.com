declare module "@salesforce/apex/NextEraHomeController.getProjects" {
  export default function getProjects(param: {searchKey: any, sortBy: any, sortDirection: any}): Promise<any>;
}
