declare module "@salesforce/apex/ParcelShareCmpController.doShareParcel" {
  export default function doShareParcel(param: {selectedDataObj: any, parcelAccess: any, parcelIds: any}): Promise<any>;
}
declare module "@salesforce/apex/ParcelShareCmpController.getParcelList" {
  export default function getParcelList(param: {recordId: any}): Promise<any>;
}
