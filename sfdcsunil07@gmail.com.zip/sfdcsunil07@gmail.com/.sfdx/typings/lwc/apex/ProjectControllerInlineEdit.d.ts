declare module "@salesforce/apex/ProjectControllerInlineEdit.fetchProjects" {
  export default function fetchProjects(): Promise<any>;
}
declare module "@salesforce/apex/ProjectControllerInlineEdit.updateProjects" {
  export default function updateProjects(param: {data: any}): Promise<any>;
}
