declare module "@salesforce/apex/FilteredTableController.getCases" {
  export default function getCases(param: {caseNumber: any, subject: any, priority: any, status: any, accountName: any, contactName: any}): Promise<any>;
}
