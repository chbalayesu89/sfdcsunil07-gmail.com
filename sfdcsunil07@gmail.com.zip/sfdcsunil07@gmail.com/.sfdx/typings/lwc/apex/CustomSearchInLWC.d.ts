declare module "@salesforce/apex/CustomSearchInLWC.retriveAccs" {
  export default function retriveAccs(param: {strAccName: any}): Promise<any>;
}
