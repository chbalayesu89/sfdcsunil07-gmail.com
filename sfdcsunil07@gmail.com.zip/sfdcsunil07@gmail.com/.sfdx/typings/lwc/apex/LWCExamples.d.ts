declare module "@salesforce/apex/LWCExamples.retriveAccs" {
  export default function retriveAccs(param: {strAccName: any}): Promise<any>;
}
