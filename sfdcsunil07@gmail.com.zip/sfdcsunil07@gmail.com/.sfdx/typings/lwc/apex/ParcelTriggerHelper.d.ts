declare module "@salesforce/apex/ParcelTriggerHelper.doShareParcels" {
  export default function doShareParcels(param: {parcellist: any}): Promise<any>;
}
