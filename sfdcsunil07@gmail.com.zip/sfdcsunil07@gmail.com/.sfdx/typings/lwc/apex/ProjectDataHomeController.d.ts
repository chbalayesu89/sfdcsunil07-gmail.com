declare module "@salesforce/apex/ProjectDataHomeController.search" {
  export default function search(param: {p_searchKey: any, p_columnName: any, p_ownerUnassigned: any}): Promise<any>;
}
declare module "@salesforce/apex/ProjectDataHomeController.multisearch" {
  export default function multisearch(param: {p_multicolumnlist: any, p_ownerUnassigned: any}): Promise<any>;
}
