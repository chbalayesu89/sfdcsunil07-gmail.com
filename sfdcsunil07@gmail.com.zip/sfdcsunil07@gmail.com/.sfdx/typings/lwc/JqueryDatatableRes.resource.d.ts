declare module "@salesforce/resourceUrl/JqueryDatatableRes" {
    var JqueryDatatableRes: string;
    export default JqueryDatatableRes;
}