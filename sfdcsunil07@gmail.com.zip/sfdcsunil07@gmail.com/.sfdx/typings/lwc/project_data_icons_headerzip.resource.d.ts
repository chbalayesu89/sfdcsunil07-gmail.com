declare module "@salesforce/resourceUrl/project_data_icons_headerzip" {
    var project_data_icons_headerzip: string;
    export default project_data_icons_headerzip;
}