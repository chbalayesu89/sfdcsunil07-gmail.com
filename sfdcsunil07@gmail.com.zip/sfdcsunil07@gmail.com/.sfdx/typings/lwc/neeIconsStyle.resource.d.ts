declare module "@salesforce/resourceUrl/neeIconsStyle" {
    var neeIconsStyle: string;
    export default neeIconsStyle;
}