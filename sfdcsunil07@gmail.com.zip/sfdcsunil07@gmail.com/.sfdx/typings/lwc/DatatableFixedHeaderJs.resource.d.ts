declare module "@salesforce/resourceUrl/DatatableFixedHeaderJs" {
    var DatatableFixedHeaderJs: string;
    export default DatatableFixedHeaderJs;
}