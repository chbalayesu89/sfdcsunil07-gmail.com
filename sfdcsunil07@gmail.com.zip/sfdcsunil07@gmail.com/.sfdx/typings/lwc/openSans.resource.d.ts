declare module "@salesforce/resourceUrl/openSans" {
    var openSans: string;
    export default openSans;
}