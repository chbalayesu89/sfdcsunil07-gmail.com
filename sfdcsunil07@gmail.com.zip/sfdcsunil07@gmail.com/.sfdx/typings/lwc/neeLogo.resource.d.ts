declare module "@salesforce/resourceUrl/neeLogo" {
    var neeLogo: string;
    export default neeLogo;
}